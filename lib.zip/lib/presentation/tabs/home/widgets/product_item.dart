import 'package:cached_network_image/cached_network_image.dart';
import 'package:fake_api_store/models/product/product_item/product_item.dart';
import 'package:fake_api_store/utils/my_colors.dart';
import 'package:fake_api_store/utils/my_fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ProductItemTable extends StatelessWidget {
  const ProductItemTable({
    Key? key,
    required this.onTap,
    required this.productItem,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            height: 110,
            width: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border:
                  Border.all(width: 1, color: MyColors.black.withOpacity(0.6)),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: CachedNetworkImage(imageUrl: productItem.image,)
            ),
          ),
          SizedBox(
            height: 11.h,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 15.w),
            child: Text(
              productItem.title,
              style: MyFonts.w600.copyWith(fontSize: 14.sp),
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          SizedBox(height: 5.h),
          Text(
            productItem.category,
            style: MyFonts.w400.copyWith(
              fontSize: 13.sp,
              color: MyColors.c666666,
            ),
          ),
          SizedBox(
            height: 5.h,
          ),
          Text(
            "\$${productItem.price}",
            style: MyFonts.w600.copyWith(fontSize: 14.sp),
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
          ),
          SizedBox(
            height: 10.h,
          ),
        ],
      ),
    );
  }

  final VoidCallback onTap;
  final ProductItem productItem;
}
