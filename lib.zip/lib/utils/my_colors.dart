import 'package:flutter/material.dart';

class MyColors {
  static const Color white = Colors.white;
  static const Color black = Colors.black;
  static const Color cF9E12B = Color(0xFFF9E12B);
  static const Color cE5E5E5 = Color(0xFFE5E5E5);
  static const Color cBFBFBF = Color(0xFFBFBFBF);
  static const Color cF3F4F5 = Color(0xFFF3F4F5);
  static const Color cAAAAAA = Color(0xFFAAAAAA);
  static const Color c666666 = Color(0xFF666666);
}
